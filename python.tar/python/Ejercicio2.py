#import librerias.joche
import librerias.ficheros

print librerias.ficheros.version()
