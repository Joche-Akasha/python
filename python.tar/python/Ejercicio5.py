import librerias.ficheros as l

l.entorno()

