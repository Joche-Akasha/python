import librerias.ficheros as l

l.visualizar('/home/oracle/proyectos/python/Ejercicio6.py')
