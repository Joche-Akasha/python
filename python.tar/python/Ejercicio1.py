import sys

print 'hola'
for x in sys.argv:
	print x

