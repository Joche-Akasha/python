import librerias.ficheros as l

l.gordo('/home/oracle/proyectos/python/',1)
